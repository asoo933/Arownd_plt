import { QueryClient } from "@tanstack/react-query";
import { createRouter, rootRouteId } from "@tanstack/react-router";
import { describe, expect, it } from "vitest";

import { routeTree } from "@/routeTree.gen";

// Match routes without running loaders or rendering: loaders may need a server or
// network the test run lacks, and jsdom never loads the stylesheets React waits on.
describe("App routing", () => {
  it("matches a page for / instead of falling back to not found", () => {
    const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });

    const matches = router.matchRoutes("/");

    expect(matches.at(-1)?.routeId).not.toBe(rootRouteId);
  });

  it("matches checkout and studio routes", () => {
    const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });

    expect(router.matchRoutes("/checkout")?.at(-1)?.routeId).toBe("/checkout");
    expect(router.matchRoutes("/studio")?.at(-1)?.routeId).toBe("/studio/");
  });

  // حماية من انحدار: كان studio.settings.tsx وorders.$orderId.tsx متداخلين تحت
  // ملفَي studio.tsx وorders.tsx (ولا يوجد <Outlet/> فيهما) فلا يُعرض مكوّنهما
  // إطلاقًا عند الزيارة — تظهر الصفحة الأم فقط، فيبدو الرابط «لا يعمل».
  it("لا يُخفي صفحات الإعدادات وتتبع الطلب تحت صفحة الأب", () => {
    const router = createRouter({ routeTree, context: { queryClient: new QueryClient() } });

    expect(router.matchRoutes("/studio/settings")?.at(-1)?.routeId).toBe("/studio/settings");
    expect(router.matchRoutes("/orders/abc")?.at(-1)?.routeId).toBe("/orders/$orderId");
    expect(router.matchRoutes("/orders/")?.at(-1)?.routeId).toBe("/orders/");
  });
});
