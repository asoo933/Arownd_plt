import { useCallback, useState, useEffect } from "react";
import { GROUPS } from "./dictionaries";

export type Lang = "ar" | "en";

const DICTIONARY: Record<Lang, Record<string, string>> = {
  ar: {
    feedback_generic_error: "تعذّر إتمام العملية. حاول مرة أخرى.",
    feedback_network_error: "تعذّر الاتصال بالإنترنت. تحقق من اتصالك وحاول مجددًا.",
    feedback_session_error: "انتهت جلستك. سجّل الدخول ثم حاول مجددًا.",
    feedback_permission_error: "ليست لديك صلاحية لتنفيذ هذا الإجراء.",
    feedback_duplicate_error: "هذه البيانات مسجلة بالفعل.",
    feedback_validation_error: "تحقق من البيانات المدخلة ثم حاول مجددًا.",
    feedback_stock_error: "الكمية المطلوبة غير متوفرة حاليًا.",
    feedback_upload_error: "تعذّر رفع الصورة. تحقق من الملف واتصالك بالإنترنت.",
    // عامة
    app_name: "Arownd",
    or: "أو",
    show_password: "إظهار كلمة المرور",
    hide_password: "إخفاء كلمة المرور",
    account_created: "تم إنشاء الحساب. يرجى تأكيد بريدك الإلكتروني ✉️",
    email_registered: "إذا كان البريد مسجلاً، سيصلك رابط استعادة كلمة المرور ✉️",
    account_creation_failed: "تعذر إنشاء الحساب. تحقق من البيانات أو جرّب بريدًا آخر",
    invalid_credentials: "البريد الإلكتروني أو كلمة المرور غير صحيحة",
    home: "الرئيسية",
    explore: "استكشف",
    map_title: "اكتشف المتاجر من حولك",
    map_search_placeholder: "ابحث عن متجر أو مكان...",
    map_search_label: "البحث على الخريطة",
    clear_search: "مسح البحث",
    map_loading: "جارٍ تحميل المتاجر...",
    map_location_hint: "فعّل الموقع لعرض المسافة",
    map_store_count: "{count} متجر",
    map_all_stores: "الكل",
    map_open_now: "مفتوح الآن",
    map_verified: "موثّق",
    map_no_match: "لا توجد متاجر تطابق خيارات البحث",
    map_no_stores: "لا توجد متاجر قريبة لعرضها حاليًا",
    map_my_location: "موقعي الحالي",
    map_location_found: "تم تحديد موقعك",
    map_view_store: "عرض المتجر",
    map_directions: "الاتجاهات",
    map_nearest: "الأقرب إليك",
    map_top_rated: "الأعلى تقييمًا",
    map_open_only: "المتاجر المفتوحة فقط",
    apply: "تطبيق",
    favorites: "المفضلة",
    orders: "طلباتي",
    profile: "الملف الشخصي",
    settings: "الإعدادات",
    my_store: "متجري",
    search: "البحث",
    cart: "السلة",
    checkout: "إتمام الشراء",
    language: "اللغة",
    arabic: "العربية",
    english: "الإنجليزية",
    save: "حفظ",
    cancel: "إلغاء",
    delete: "حذف",
    edit: "تعديل",
    back: "رجوع",
    continue: "متابعة",
    loading: "جاري التحميل...",
    error: "حدث خطأ",
    success: "تم بنجاح",
    try_again: "حاول مرة أخرى",
    close: "إغلاق",
    send: "إرسال",
    phone: "رقم الهاتف",
    email: "البريد الإلكتروني",
    password: "كلمة المرور",
    confirm_password: "تأكيد كلمة المرور",
    name: "الاسم",
    address: "العنوان",
    city: "المدينة",
    state: "الولاية",
    country: "الدولة",
    sign_in: "تسجيل الدخول",
    sign_up: "إنشاء حساب",
    sign_out: "تسجيل الخروج",
    forgot_password: "نسيت كلمة المرور؟",
    reset_password: "إعادة تعيين كلمة المرور",
    reset_link_sent: "أُرسل رابط استعادة كلمة المرور إلى بريدك ✉️",
    password_updated: "تم تحديث كلمة المرور بنجاح 🔒",
    passwords_do_not_match: "كلمتا المرور غير متطابقتين",
    enter_email: "أدخل بريدك الإلكتروني",
    enter_password: "أدخل كلمة المرور",
    enter_name: "أدخل اسمك",
    enter_phone: "أدخل رقم هاتفك",
    enter_address: "أدخل عنوانك",
    no_results: "لا توجد نتائج",
    no_items: "لا توجد عناصر",
    add_to_cart: "أضف إلى السلة",
    best_price: "أفضل سعر",
    added_to_cart: "أُضيف إلى السلة",
    remove_from_cart: "أزل من السلة",
    cart_empty: "سلة التسوق فارغة",
    cart_total: "المجموع",
    checkout_now: "أكمل الطلب الآن",
    order_placed: "تم وضع الطلب بنجاح",
    order_tracking: "تتبع الطلب",
    order_status: "حالة الطلب",
    pending: "قيد الانتظار",
    confirmed: "مؤكد",
    shipped: "تم الشحن",
    delivered: "تم التوصيل",
    cancelled: "ملغي",
    store_settings: "إعدادات المتجر",
    store_name: "اسم المتجر",
    store_description: "وصف المتجر",
    store_logo: "شعار المتجر",
    store_cover: "صورة الغلاف",
    store_hours: "ساعات العمل",
    store_holidays: "أيام العطلة",
    social_links: "روابط التواصل الاجتماعي",
    instagram: "إنستغرام",
    facebook: "فيسبوك",
    account_info: "معلومات الحساب",
    account_security: "الأمان وتسجيل الدخول",
    account_addresses: "عناويني",
    manage_addresses: "إدارة عناوين التوصيل",
    my_products: "منتجاتي",
    my_orders: "طلباتي",
    my_favorites: "مفضلاتي",
    help: "المساعدة",
    about: "حول التطبيق",
    privacy: "سياسة الخصوصية",
    terms: "شروط الاستخدام",
    language_changed: "تم تغيير اللغة",
    dark_mode: "الوضع الليلي",
    notifications: "الإشعارات",
    notifications_on: "تشغيل الإشعارات",
    notifications_off: "إيقاف الإشعارات",
    version: "الإصدار",
    app_version: "الإصدار 1.0.0",
    contact_us: "اتصل بنا",
    report_issue: "إبلاغ عن مشكلة",
    rate_app: "قيم التطبيق",
    share_app: "شارك التطبيق",
    logout_confirm: "هل أنت متأكد أنك تريد تسجيل الخروج؟",
    yes: "نعم",
    no: "لا",
    ok: "موافق",
    required: "هذا الحقل مطلوب",
    invalid_email: "البريد الإلكتروني غير صالح",
    invalid_phone: "رقم الهاتف غير صالح",
    password_too_short: "كلمة المرور قصيرة جداً (أقلها 6 أحرف)",
    welcome_back: "مرحباً بعودتك",
    welcome: "مرحباً",
    good_morning: "صباح الخير",
    good_evening: "مساء الخير",
    today: "اليوم",
    yesterday: "أمس",
    tomorrow: "غداً",
    now: "الآن",
    minutes_ago: "منذ دقائق",
    hours_ago: "منذ ساعات",
    days_ago: "منذ أيام",
    recent: "الأحدث",
    popular: "الأكثر شعبية",
    newest: "الأحدث",
    price_low_to_high: "السعر من الأقل إلى الأعلى",
    price_high_to_low: "السعر من الأعلى إلى الأقل",
    filter: "تصفية",
    sort: "ترتيب حسب",
    categories: "التصنيفات",
    products: "المنتجات",
    stores: "المتاجر",
    product_details: "تفاصيل المنتج",
    product_description: "وصف المنتج",
    product_price: "سعر المنتج",
    product_stock: "التوفر",
    in_stock: "متوفر",
    out_of_stock: "غير متوفر",
    quantity: "الكمية",
    total: "المجموع",
    shipping: "الشحن",
    delivery: "التوصيل",
    payment: "الدفع",
    payment_method: "طريقة الدفع",
    cash_on_delivery: "الدفع عند الاستلام",
    card: "بطاقة ائتمانية",
    online_payment: "دفع إلكتروني",
    order_summary: "ملخص الطلب",
    items: "عناصر",
    subtotal: "المجموع الفرعي",
    tax: "الضريبة",
    discount: "الخصم",
    coupon: "كوبون خصم",
    apply_coupon: "تطبيق الكوبون",
    promo_code: "رمز ترويجي",
    gift_card: "بطاقة هدايا",
    track_order: "تتبع طلبك",
    order_history: "سجل الطلبات",
    reorder: "إعادة الطلب",
    cancel_order: "إلغاء الطلب",
    return_order: "إرجاع الطلب",
    write_review: "اكتب مراجعة",
    rating: "التقييم",
    reviews: "المراجعات",
    share: "مشاركة",
    save_for_later: "احفظ لوقت لاحق",
    compare: "مقارنة",
    wishlist: "قائمة الأمنيات",
    recently_viewed: "تم عرضها مؤخراً",
    recommended_for_you: "موصى بها لك",
    best_sellers: "الأكثر مبيعاً",
    new_arrivals: "وصل حديثاً",
    on_sale: "تخفيضات",
    free_shipping: "شحن مجاني",
    cash_on_delivery_available: "دفع عند الاستلام متاح",
    store_info: "معلومات المتجر",
    store_rating: "تقييم المتجر",
    store_followers: "المتابعون",
    store_products: "منتجات المتجر",
    follow_store: "متابعة المتجر",
    unfollow_store: "إلغاء متابعة المتجر",
    message_store: "راسل المتجر",
    call_store: "اتصل بالمتجر",
    visit_store: "زيارة المتجر",
    store_location: "موقع المتجر",
    store_opens: "يفتح في",
    store_closes: "يُغلق في",
    store_open_now: "مفتوح الآن",
    store_closed_now: "مغلق الآن",
    delivery_time: "وقت التوصيل",
    delivery_fee: "رسوم التوصيل",
    delivery_address: "عنوان التوصيل",
    delivery_date: "تاريخ التوصيل",
    delivery_slot: "موعد التوصيل",
    asap: "بأسرع ما يمكن",
    schedule: "جدولة",
    pickup: "استلام من المتجر",
    ship_to_me: "شحن لي",
    gift_wrap: "تغليف هدايا",
    add_note: "أضف ملاحظة",
    special_instructions: "تعليمات خاصة",
    promo_applied: "تم تطبيق العرض الترويجي",
    invalid_coupon: "كوبون غير صالح",
    coupon_expired: "الكوبون منتهي الصلاحية",
    out_of_stock_msg: "هذا المنتج غير متوفر حالياً",
    low_stock: "كمية محدودة متوفرة",
    back_in_stock: "عود إلى المخزون",
    notify_me: "أعلمني عند التوفر",
    product_added_to_wishlist: "أُضيف إلى قائمة الأمنيات",
    product_removed_from_wishlist: "أُزيل من قائمة الأمنيات",
    already_in_wishlist: "المنتج موجود بالفعل في قائمة الأمنيات",
    login_required: "يتطلب تسجيل الدخول",
    create_account_prompt: "لا تملك حساباً بعد؟ أنشئ حساباً",
    already_have_account: "لديك حساب بالفعل؟ تسجيل الدخول",
    terms_agreement: "بالمتابعة، أنت توافق على",
    terms_of_service: "شروط الخدمة",
    privacy_policy: "سياسة الخصوصية",
    and: "و",
    verify_email: "تحقق من بريدك الإلكتروني",
    verify_phone: "تحقق من رقم هاتفك",
    otp_sent: "أُرسل رمز التحقق",
    enter_otp: "أدخل رمز التحقق",
    resend_otp: "إعادة إرسال الرمز",
    otp_expired: "انتهت صلاحية الرمز",
    invalid_otp: "رمز التحقق غير صالح",
    two_factor: "التحقق الثنائي",
    two_factor_desc: "أضف طبقة أمان إضافية لحسابك",
    enable_2fa: "تفعيل التحقق الثنائي",
    disable_2fa: "إلغاء تفعيل التحقق الثنائي",
    backup_codes: "رموز النسخ الاحتياطي",
    recovery_code: "رمز الاسترداد",
    session: "الجلسة",
    active_sessions: "الجلسات النشطة",
    sign_out_all: "تسجيل الخروج من جميع الأجهزة",
    device: "الجهاز",
    location: "الموقع",
    last_active: "آخر نشاط",
    data_export: "تصدير البيانات",
    data_import: "استيراد البيانات",
    delete_account: "حذف الحساب",
    delete_account_confirm: "سيتم حذف جميع بياناتك نهائياً ولا يمكن التراجع",
    deactivate_account: "تعطيل الحساب مؤقتاً",
    reactivate_account: "إعادة تفعيل الحساب",
    close_account: "إغلاق الحساب",
    close_account_confirm: "هل أنت متأكد من إغلاق حسابك؟",
    data_retention: "سياسة الاحتفاظ بالبيانات",
    cookie_policy: "سياسة ملفات تعريف الارتباط",
    cookie_consent: "نستخدم ملفات تعريف الارتباط لتحسين تجربتك",
    accept_cookies: "قبول",
    reject_cookies: "رفض",
    manage_cookies: "إدارة التفضيلات",
    accessibility: "سهولة الوصول",
    high_contrast: "تباين عالي",
    large_text: "نص كبير",
    screen_reader: "قارئ الشاشة",
    reduce_motion: "تقليل الحركة",
    keyboard_navigation: "التنقل بلوحة المفاتيح",
    skip_to_content: "تجاوز إلى المحتوى",
    beta: "نسخة تجريبية",
    feedback: "ملاحظات",
    bug_report: "إبلاغ عن خطأ",
    feature_request: "طلب ميزة",
    support_email: "البريد الإلكتروني للدعم",
    support_phone: "رقم دعم العملاء",
    support_hours: "ساعات الدعم",
    business_hours: "ساعات العمل",
    timezone: "المنطقة الزمنية",
    currency: "العملة",
    currency_dzd: "دينار جزائري (DZD)",
    currency_usd: "دولار أمريكي (USD)",
    currency_eur: "يورو (EUR)",
    region: "المنطقة",
    region_algiers: "الجزائر",
    region_oran: "وهران",
    region_constantine: "قسنطينة",
    region_annaba: "عنابة",
    region_blida: "البليدة",
    region_batna: "باتنة",
    region_setif: "سطيف",
    region_tlemcen: "تلمسان",
    region_bejaia: "بجاية",
    region_ouargla: "ورقلة",
    region_tindouf: "تندوف",
    region_ghardaia: "غرداية",
    region_adrar: "أدرار",
    region_illizi: "إيليزي",
    region_tamanrasset: "تمنراست",
    delivery_dashboard: "لوحة التوصيل",
    delivery_nav_home: "الرئيسية",
  },
  en: {
    feedback_generic_error: "We couldn't complete that action. Please try again.",
    feedback_network_error: "Couldn't connect. Check your internet connection and try again.",
    feedback_session_error: "Your session has expired. Sign in and try again.",
    feedback_permission_error: "You don't have permission to do that.",
    feedback_duplicate_error: "These details are already registered.",
    feedback_validation_error: "Please check the entered details and try again.",
    feedback_stock_error: "The requested quantity is currently unavailable.",
    feedback_upload_error: "Couldn't upload the image. Check the file and your connection.",
    // General
    app_name: "Arownd",
    or: "or",
    show_password: "Show password",
    hide_password: "Hide password",
    account_created: "Account created. Please check your email ✉️",
    email_registered: "If the email is registered, you will receive a password reset link ✉️",
    account_creation_failed: "Failed to create account. Check your data or try another email",
    invalid_credentials: "Invalid email or password",
    home: "Home",
    explore: "Explore",
    map_title: "Discover stores around you",
    map_search_placeholder: "Search for a store or place...",
    map_search_label: "Search the map",
    clear_search: "Clear search",
    map_loading: "Loading stores...",
    map_location_hint: "Enable location to see distances",
    map_store_count: "{count} stores",
    map_all_stores: "All",
    map_open_now: "Open now",
    map_verified: "Verified",
    map_no_match: "No stores match your current filters",
    map_no_stores: "No nearby stores to show right now",
    map_my_location: "My location",
    map_location_found: "Your location was found",
    map_view_store: "View store",
    map_directions: "Directions",
    map_nearest: "Nearest to you",
    map_top_rated: "Top rated",
    map_open_only: "Open stores only",
    apply: "Apply",
    favorites: "Favorites",
    orders: "My Orders",
    profile: "Profile",
    settings: "Settings",
    my_store: "My Store",
    search: "Search",
    cart: "Cart",
    checkout: "Checkout",
    language: "Language",
    arabic: "Arabic",
    english: "English",
    save: "Save",
    cancel: "Cancel",
    delete: "Delete",
    edit: "Edit",
    back: "Back",
    continue: "Continue",
    loading: "Loading...",
    error: "An error occurred",
    success: "Success",
    try_again: "Try again",
    close: "Close",
    send: "Send",
    phone: "Phone Number",
    email: "Email Address",
    password: "Password",
    confirm_password: "Confirm Password",
    name: "Name",
    address: "Address",
    city: "City",
    state: "State/Province",
    country: "Country",
    sign_in: "Sign In",
    sign_up: "Create Account",
    sign_out: "Sign Out",
    forgot_password: "Forgot password?",
    reset_password: "Reset Password",
    reset_link_sent: "Password reset link sent to your email ✉️",
    password_updated: "Password updated successfully 🔒",
    passwords_do_not_match: "Passwords do not match",
    enter_email: "Enter your email",
    enter_password: "Enter your password",
    enter_name: "Enter your name",
    enter_phone: "Enter your phone number",
    enter_address: "Enter your address",
    no_results: "No results found",
    no_items: "No items",
    add_to_cart: "Add to Cart",
    best_price: "Best price",
    added_to_cart: "Added to cart",
    remove_from_cart: "Remove from cart",
    cart_empty: "Shopping cart is empty",
    cart_total: "Total",
    checkout_now: "Complete order now",
    order_placed: "Order placed successfully",
    order_tracking: "Order Tracking",
    order_status: "Order Status",
    pending: "Pending",
    confirmed: "Confirmed",
    shipped: "Shipped",
    delivered: "Delivered",
    cancelled: "Cancelled",
    store_settings: "Store Settings",
    store_name: "Store Name",
    store_description: "Store Description",
    store_logo: "Store Logo",
    store_cover: "Cover Image",
    store_hours: "Store Hours",
    store_holidays: "Holidays",
    social_links: "Social Links",
    instagram: "Instagram",
    facebook: "Facebook",
    account_info: "Account Information",
    account_security: "Security & Sign In",
    account_addresses: "My Addresses",
    manage_addresses: "Manage Delivery Addresses",
    my_products: "My Products",
    my_orders: "My Orders",
    my_favorites: "My Favorites",
    help: "Help",
    about: "About",
    privacy: "Privacy Policy",
    terms: "Terms of Service",
    language_changed: "Language changed",
    dark_mode: "Dark Mode",
    notifications: "Notifications",
    notifications_on: "Turn on notifications",
    notifications_off: "Turn off notifications",
    version: "Version",
    app_version: "Version 1.0.0",
    contact_us: "Contact Us",
    report_issue: "Report an Issue",
    rate_app: "Rate the App",
    share_app: "Share the App",
    logout_confirm: "Are you sure you want to sign out?",
    yes: "Yes",
    no: "No",
    ok: "OK",
    required: "This field is required",
    invalid_email: "Invalid email address",
    invalid_phone: "Invalid phone number",
    password_too_short: "Password too short (minimum 6 characters)",
    welcome_back: "Welcome back",
    welcome: "Welcome",
    good_morning: "Good morning",
    good_evening: "Good evening",
    today: "Today",
    yesterday: "Yesterday",
    tomorrow: "Tomorrow",
    now: "Now",
    minutes_ago: "minutes ago",
    hours_ago: "hours ago",
    days_ago: "days ago",
    recent: "Latest",
    popular: "Most Popular",
    newest: "Newest",
    price_low_to_high: "Price low to high",
    price_high_to_low: "Price high to low",
    filter: "Filter",
    sort: "Sort by",
    categories: "Categories",
    products: "Products",
    stores: "Stores",
    product_details: "Product Details",
    product_description: "Product Description",
    product_price: "Product Price",
    product_stock: "Availability",
    in_stock: "In Stock",
    out_of_stock: "Out of Stock",
    quantity: "Quantity",
    total: "Total",
    shipping: "Shipping",
    delivery: "Delivery",
    payment: "Payment",
    payment_method: "Payment Method",
    cash_on_delivery: "Cash on Delivery",
    card: "Credit Card",
    online_payment: "Online Payment",
    order_summary: "Order Summary",
    items: "Items",
    subtotal: "Subtotal",
    tax: "Tax",
    discount: "Discount",
    coupon: "Coupon",
    apply_coupon: "Apply Coupon",
    promo_code: "Promo Code",
    gift_card: "Gift Card",
    track_order: "Track Your Order",
    order_history: "Order History",
    reorder: "Reorder",
    cancel_order: "Cancel Order",
    return_order: "Return Order",
    write_review: "Write a Review",
    rating: "Rating",
    reviews: "Reviews",
    share: "Share",
    save_for_later: "Save for Later",
    compare: "Compare",
    wishlist: "Wishlist",
    recently_viewed: "Recently Viewed",
    recommended_for_you: "Recommended for You",
    best_sellers: "Best Sellers",
    new_arrivals: "New Arrivals",
    on_sale: "On Sale",
    free_shipping: "Free Shipping",
    cash_on_delivery_available: "Cash on Delivery Available",
    store_info: "Store Information",
    store_rating: "Store Rating",
    store_followers: "Followers",
    store_products: "Store Products",
    follow_store: "Follow Store",
    unfollow_store: "Unfollow Store",
    message_store: "Message Store",
    call_store: "Call Store",
    visit_store: "Visit Store",
    store_location: "Store Location",
    store_opens: "Opens at",
    store_closes: "Closes at",
    store_open_now: "Open now",
    store_closed_now: "Closed now",
    delivery_time: "Delivery Time",
    delivery_fee: "Delivery Fee",
    delivery_address: "Delivery Address",
    delivery_date: "Delivery Date",
    delivery_slot: "Delivery Slot",
    asap: "ASAP",
    schedule: "Schedule",
    pickup: "Store Pickup",
    ship_to_me: "Ship to Me",
    gift_wrap: "Gift Wrap",
    add_note: "Add Note",
    special_instructions: "Special Instructions",
    promo_applied: "Promo applied",
    invalid_coupon: "Invalid coupon",
    coupon_expired: "Coupon expired",
    out_of_stock_msg: "This product is currently out of stock",
    low_stock: "Limited quantity available",
    back_in_stock: "Back in stock",
    notify_me: "Notify me when available",
    product_added_to_wishlist: "Added to wishlist",
    product_removed_from_wishlist: "Removed from wishlist",
    already_in_wishlist: "Product already in wishlist",
    login_required: "Login required",
    create_account_prompt: "Don't have an account? Create one",
    already_have_account: "Already have an account? Sign in",
    terms_agreement: "By continuing, you agree to",
    terms_of_service: "Terms of Service",
    privacy_policy: "Privacy Policy",
    and: "and",
    verify_email: "Verify your email",
    verify_phone: "Verify your phone",
    otp_sent: "Verification code sent",
    enter_otp: "Enter verification code",
    resend_otp: "Resend code",
    otp_expired: "Code expired",
    invalid_otp: "Invalid verification code",
    two_factor: "Two-Factor Authentication",
    two_factor_desc: "Add an extra layer of security to your account",
    enable_2fa: "Enable two-factor authentication",
    disable_2fa: "Disable two-factor authentication",
    backup_codes: "Backup codes",
    recovery_code: "Recovery code",
    session: "Session",
    active_sessions: "Active Sessions",
    sign_out_all: "Sign out of all devices",
    device: "Device",
    location: "Location",
    last_active: "Last active",
    data_export: "Export Data",
    data_import: "Import Data",
    delete_account: "Delete Account",
    delete_account_confirm: "All your data will be permanently deleted and cannot be undone",
    deactivate_account: "Deactivate account temporarily",
    reactivate_account: "Reactivate account",
    close_account: "Close Account",
    close_account_confirm: "Are you sure you want to close your account?",
    data_retention: "Data Retention Policy",
    cookie_policy: "Cookie Policy",
    cookie_consent: "We use cookies to improve your experience",
    accept_cookies: "Accept",
    reject_cookies: "Reject",
    manage_cookies: "Manage preferences",
    accessibility: "Accessibility",
    high_contrast: "High Contrast",
    large_text: "Large Text",
    screen_reader: "Screen Reader",
    reduce_motion: "Reduce Motion",
    keyboard_navigation: "Keyboard Navigation",
    skip_to_content: "Skip to content",
    beta: "Beta",
    feedback: "Feedback",
    bug_report: "Bug Report",
    feature_request: "Feature Request",
    support_email: "Support Email",
    support_phone: "Customer Support Phone",
    support_hours: "Support Hours",
    business_hours: "Business Hours",
    timezone: "Timezone",
    currency: "Currency",
    currency_dzd: "Algerian Dinar (DZD)",
    currency_usd: "US Dollar (USD)",
    currency_eur: "Euro (EUR)",
    region: "Region",
    region_algiers: "Algiers",
    region_oran: "Oran",
    region_constantine: "Constantine",
    region_annaba: "Annaba",
    region_blida: "Blida",
    region_batna: "Batna",
    region_setif: "Setif",
    region_tlemcen: "Tlemcen",
    region_bejaia: "Bejaia",
    region_ouargla: "Ouargla",
    region_tindouf: "Tindouf",
    region_ghardaia: "Ghardaia",
    region_adrar: "Adrar",
    region_illizi: "Illizi",
    region_tamanrasset: "Tamanrasset",
    delivery_dashboard: "Delivery",
    delivery_nav_home: "Home",
  },
};

const STORAGE_KEY = "sooqy:lang";

/**
 * تفعيل الواجهة الإنجليزية بعد اكتمال مراجعة القواميس العربية والإنجليزية.
 */
export const ENGLISH_ENABLED = true;

/** يحوّل أي لغة مطلوبة إلى لغة مفعّلة فعلًا. */
export function resolveEnabledLang(lang: Lang): Lang {
  return lang === "en" && !ENGLISH_ENABLED ? "ar" : lang;
}

// دمج المجموعات الإضافية (لكل شاشة) في القاموس الأساسي.
for (const group of GROUPS) {
  Object.assign(DICTIONARY.ar, group.ar);
  Object.assign(DICTIONARY.en, group.en);
}

/**
 * محلّاب لغة الطلب على الخادم — يُسجَّل من `src/server.ts`.
 * يقرأ ترويسة الطلب مباشرة، فلا يحدث تعارض بين الطلبات المتوازية.
 */
// يُحفظ على globalThis لأن الخادم وSSR قد يُحمَّلان في سياقي وحدات مختلفين
// (Vite dev / حزمة الإنتاج) — فالمتغير العادي لا يُشارَك بينهما.
const REGISTRY = globalThis as typeof globalThis & {
  __sooqyLangResolver?: () => Lang | null;
};

export function registerServerLangResolver(fn: () => Lang | null) {
  REGISTRY.__sooqyLangResolver = fn;
}

/** يقرأ لغة التطبيق من كوكي `sooqy:lang`. */
function readLangCookie(): Lang | null {
  if (typeof document === "undefined") return null;
  const match = /(?:^|;\s*)sooqy:lang=(ar|en)(?:;|$)/.exec(document.cookie);
  return match ? (match[1] as Lang) : null;
}

export function getSavedLang(): Lang {
  if (!ENGLISH_ENABLED) return "ar";
  if (typeof window === "undefined") {
    // على الخادم: لغة الطلب (بادئة المسار) ثم الافتراضي.
    try {
      return REGISTRY.__sooqyLangResolver?.() ?? DEFAULT_LANG;
    } catch {
      return DEFAULT_LANG;
    }
  }
  // الكوكي يreflect عنوان المسار (`/en/...`) — وهو الأحدث نية للمستخدم.
  const fromCookie = readLangCookie();
  if (fromCookie) return fromCookie;
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved === "ar" || saved === "en") return saved;
  // افتراضياً العربية حسب لغة المتصفح إن كانت إنجليزية فقط
  return navigator.language?.startsWith("en") ? "en" : "ar";
}

export function saveLang(lang: Lang) {
  if (typeof window === "undefined") return;
  localStorage.setItem(STORAGE_KEY, lang);
}

/** قيم تُستبدل داخل النص: `{name}` و`{count}` ... */
export type TranslateValues = Record<string, string | number> & { count?: number };

/**
 * صيغة الجمع حسب اللغة.
 * العربية: صفر · واحد · اثنان · قليل (3-10) · كثير (11-99) · آخر (100+).
 * الإنجليزية: واحد · آخر.
 */
export type PluralForm = "zero" | "one" | "two" | "few" | "many" | "other";

export function pluralForm(count: number, lang: Lang): PluralForm {
  const n = Math.abs(count);
  if (lang === "en") return n === 1 ? "one" : "other";
  if (n === 0) return "zero";
  if (n === 1) return "one";
  if (n === 2) return "two";
  if (n % 100 >= 3 && n % 100 <= 10) return "few";
  if (n % 100 >= 11) return "many";
  return "other";
}

/** يستبدل `{name}` بالقيمة. */
function interpolate(template: string, values?: TranslateValues): string {
  if (!values) return template;
  return template.replace(/\{(\w+)\}/g, (match, key: string) => {
    const v = values[key];
    return v === undefined ? match : String(v);
  });
}

/**
 * يبحث عن المفتاح: أولًا بصيغة الجمع المخصّصة، ثم المفتاح المباشر،
 * ثم اللغة الأخرى (كسلاح أمان — لا يظهر المفتاح الخام للمستخدم أبدًا).
 */
function lookup(key: string, lang: Lang, values?: TranslateValues): string | undefined {
  const dict = DICTIONARY[lang] ?? {};
  if (values?.count !== undefined) {
    const form = pluralForm(values.count, lang);
    const pluralKey = `${key}_${form}`;
    const plural = dict[pluralKey];
    if (plural !== undefined) return plural;
  }
  const direct = dict[key];
  if (direct !== undefined) return direct;
  // احتياطي: نفس المفتاح في اللغة الأخرى
  const other = lang === "ar" ? DICTIONARY.en?.[key] : DICTIONARY.ar?.[key];
  return other;
}

export function t(key: string, lang: Lang, values?: TranslateValues): string {
  const found = lookup(key, lang, values);
  if (found === undefined) {
    if (import.meta.env?.DEV) console.warn(`[i18n] مفتاح مفقود: ${key}`);
    return key;
  }
  return interpolate(found, values);
}

/**
 * ترجمة خارج مكوّن React — تُستخدم في `head` (وسوم الميتا) حيث لا تتوفر Hooks.
 * على الخادم تعيد العربية (السوق الافتراضي)؛ في المتصفح تتبع اللغة المحفوظة.
 */
function getRenderLang(): Lang {
  if (typeof document !== "undefined") {
    const rendered = document.documentElement.lang;
    if (rendered === "ar" || rendered === "en") return rendered;
  }
  return getSavedLang();
}

export function translate(key: string, values?: TranslateValues): string {
  return t(key, getRenderLang(), values);
}

/** لغة Open Graph حسب اللغة النشطة (`ar_DZ` / `en_DZ`). */
export function ogLocale(): "ar_DZ" | "en_DZ" {
  return getRenderLang() === "en" ? "en_DZ" : "ar_DZ";
}

export function useTranslation() {
  // Reuse the server-rendered document language on the first client render.
  // Restore local preferences only after hydration to prevent HTML divergence.
  const [lang, setLang] = useState<Lang>(() => getRenderLang());

  useEffect(() => {
    setLang(getSavedLang());
  }, []);

  useEffect(() => {
    saveLang(lang);
    document.documentElement.lang = lang;
    document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  }, [lang]);

  const tr = useCallback((key: string, values?: TranslateValues) => t(key, lang, values), [lang]);

  const switchLang = useCallback((newLang: Lang) => {
    setLang(resolveEnabledLang(newLang));
  }, []);

  return { lang, t: tr, switchLang, isRTL: lang === "ar" };
}

export const DEFAULT_LANG: Lang = "ar";
